DDL_QUERY =  '''
CREATE TABLE IF NOT EXISTS p_school(
    id_school INT PRIMARY KEY,
    school VARCHAR(4) UNIQUE
);

CREATE TABLE IF NOT EXISTS p_sex(
    id_sex INT PRIMARY KEY,
    sexo VARCHAR(4) UNIQUE
);

CREATE TABLE IF NOT EXISTS p_job(
    id_job INT PRIMARY KEY,
    job_name VARCHAR(15) ,
    relationship VARCHAR(15) 
);

CREATE TABLE IF NOT EXISTS p_age(
    id_age INT PRIMARY KEY,
    age VARCHAR(4) UNIQUE
);

CREATE TABLE IF NOT EXISTS p_guardian(
    id_guardian INT PRIMARY KEY,
    guardian VARCHAR(15) UNIQUE
);

CREATE TABLE IF NOT EXISTS p_internet(
    id_internet INT PRIMARY KEY,
    internet VARCHAR(4) UNIQUE
);

CREATE TABLE IF NOT EXISTS p_romantic(
    id_romantic INT PRIMARY KEY,
    romantic VARCHAR(4) UNIQUE
);

CREATE TABLE IF NOT EXISTS p_grades(
    id_grades BIGINT PRIMARY KEY,
    id_school INT,
	id_sex INT,
    id_age INT,
	id_job INT,
    id_guardian INT,
	id_internet INT,
    id_romantic INT,
	g1 INT,
    g2 INT,
    g3 INT,
    subject varchar(10),
    
    CONSTRAINT fk_school_type
        FOREIGN KEY (id_school)
            REFERENCES p_school(id_school),

    CONSTRAINT fk_sex_type
        FOREIGN KEY (id_sex)
            REFERENCES p_sex(id_sex),
    
    CONSTRAINT fk_job_type
        FOREIGN KEY (id_job)
            REFERENCES p_job(id_job),

    CONSTRAINT fk_ages
        FOREIGN KEY (id_age)
            REFERENCES p_age(id_age),

    CONSTRAINT fk_guardian_type
        FOREIGN KEY (id_guardian)
            REFERENCES p_guardian(id_guardian),
    
    CONSTRAINT fk_internet
        FOREIGN KEY (id_internet)
            REFERENCES p_internet(id_internet),

    CONSTRAINT fk_romantic
        FOREIGN KEY (id_romantic)
            REFERENCES p_romantic(id_romantic)
);

SELECT * FROM p_guardian;
 '''